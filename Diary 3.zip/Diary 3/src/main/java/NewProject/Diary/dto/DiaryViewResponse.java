package NewProject.Diary.dto;

import NewProject.Diary.domain.Diary;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@NoArgsConstructor
@Getter
public class DiaryViewResponse {
    private Long id;
    private String title;
    private String text;
    private String writeDate;

    public DiaryViewResponse(Diary diary) {
        this.id = diary.getId();
        this.writeDate = diary.getWriteDate();
        this.title = diary.getTitle();
        this.text = diary.getText();
    }
}
