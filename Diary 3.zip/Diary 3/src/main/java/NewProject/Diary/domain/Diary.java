package NewProject.Diary.domain;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
@EntityListeners(AuditingEntityListener.class)
@Entity
@Getter @Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Diary {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    private Long id;
    @Column(name = "write_date", nullable = false)
    private String writeDate;
    @Column(name = "title", nullable = false)
    private String title;
    @Column(name = "text")
    private String text;

    @Builder
    public Diary(Long id, String title, String text){
        this.id = id;
        this.title = title;
        this.text = text;
        this.writeDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yy.MM.dd HH:mm"));
    }

    public void update(String title, String text){
        this.title = title;
        this.text = text;
    }

}